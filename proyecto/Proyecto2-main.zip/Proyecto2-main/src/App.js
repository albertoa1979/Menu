import React from 'react';
import './App.css';
import Principal from './principal55';

function App() {
  return (
    <div className="App">
      <Principal/> 
    </div>
  );
}

export default App;