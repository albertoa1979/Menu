import React, {useState} from "react";
import ProductCatalog from "./Catalogo";

function Prueba () {
  const [mostrarComponente, setMostrarComponente] = useState(false);

  const handleClickImagen1 = () => {
    setMostrarComponente(true);
  }

  const handleClickImagen2 = () => {
    setMostrarComponente(true);
  }

  return (
    <div className="container">
      <h1 className="title">
        Bienvenidos a Agrivet <span aria-label="emoji" role="img"></span>
      </h1>

      <center>
        <table>
          <tbody>
            <tr>
              <td>
                <img src='productos.png' width="425" height="100" onClick={handleClickImagen1} />
              </td>
            </tr>

            <tr>
              <td>
                <img src='home.png' width="200" height="170" onClick={handleClickImagen2} />
              </td>
            </tr>
          </tbody>
        </table>
      </center>

      {mostrarComponente && <ProductCatalog />}
    </div>
  );
}

export default Prueba;